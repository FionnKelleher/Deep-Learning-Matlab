%%Opening the Deep Learning Model Hub in a browser
web("https://github.com/matlab-deep-learning/MATLAB-Deep-Learning-Model-Hub")